import {writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const frames=path.join(root,'generated/frames');
const mask=path.join(root,'generated/head-isolation-mask.png');
const head=path.join(root,'generated/shared-generated-head.png');
// Mechanical part isolation of an imagegen drawing. The same pixels are reused,
// never repainted or morphed. The lower polygon boundary follows neck/collar.
execFileSync('magick',['-size','512x512','canvas:black','-fill','white','-draw','polygon 277,90 367,90 367,186 344,187 331,190 313,190 303,174 284,160',mask]);
// Convert the crop polygon's luminance to alpha, preserving the source's edge alpha.
execFileSync('magick',[mask,'-alpha','copy',path.join(root,'generated/head-mask-alpha.png')]);
execFileSync('magick',[path.join(frames,'run-0.png'),path.join(root,'generated/head-mask-alpha.png'),'-compose','DstIn','-composite',head]);
const offsets=[0,4,-4,-2,0,4,-4,-2];
for(let f=0;f<8;f++){
 const geometry=`+0${offsets[f]<0?'':'+'}${offsets[f]}`;
 execFileSync('magick',[path.join(frames,`run-${f}.png`),path.join(root,'generated/head-mask-alpha.png'),'-geometry',geometry,'-compose','DstOut','-composite',head,'-geometry',geometry,'-compose','Over','-composite',path.join(frames,`stable-${f}.png`)]);
}
const args=['-size','2048x1024','canvas:none'];for(let f=0;f<8;f++)args.push(path.join(frames,`stable-${f}.png`),'-geometry',`+${f%4*512}+${Math.floor(f/4)*512}`,'-compose','Over','-composite');
execFileSync('magick',[...args,path.join(root,'generated/run-stable-head.png')]);
writeFileSync(path.join(root,'stable-head.json'),JSON.stringify({source:'generated/frames/run-0.png',output:'generated/run-stable-head.png',isolationPolygon:[[277,90],[367,90],[367,186],[344,187],[331,190],[313,190],[303,174],[284,160]],headOffsets:offsets.map(y=>[0,y]),note:'One unchanged generated head reused across all poses. This tests facial stability, not limb mechanics. It is based on candidate frame0, not an exact pixel copy of the approved widget.'},null,2)+'\n');
console.log('Packed stable-head experiment');
