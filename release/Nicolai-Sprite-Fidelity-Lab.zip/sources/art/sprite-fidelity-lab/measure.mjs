import {execFileSync} from 'node:child_process';
import {writeFileSync,readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=(name)=>execFileSync('magick',[path.join(root,'generated/frames',name),'-depth','8','rgba:-'],{maxBuffer:5e6});
const offsets=[0,4,-4,-2,0,4,-4,-2];
const base=read('stable-0.png');
const baseRegular=read('run-0.png');
const rows=[];
for(let f=0;f<8;f++){
 const fixed=read(`stable-${f}.png`),regular=read(`run-${f}.png`);let changed=0,originalChanged=0,diff=0,originalDiff=0,measured=0;let minX=512,minY=512,maxX=0,maxY=0;
 for(let y=0;y<512;y++)for(let x=0;x<512;x++){if(fixed[(y*512+x)*4+3]>64){minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}}
 // Compare the same aligned face region, compensating only for authored bob.
 for(let y=104;y<171;y++)for(let x=300;x<356;x++){
 const p=(y*512+x)*4,q=((y+offsets[f])*512+x)*4;let match=true,originalMatch=true;
 for(let c=0;c<4;c++){if(base[p+c]!==fixed[q+c])match=false;if(baseRegular[p+c]!==regular[q+c])originalMatch=false;diff+=Math.abs(base[p+c]-fixed[q+c]);originalDiff+=Math.abs(baseRegular[p+c]-regular[q+c]);}
 if(!match)changed++;if(!originalMatch)originalChanged++;measured++;
 }
 rows.push({frame:f,facePixelsCompared:measured,sharedHeadDifferingPixels:changed,registeredHeadDifferingPixels:originalChanged,sharedHeadMeanAbsoluteChannelDifference:diff/(measured*4),registeredHeadMeanAbsoluteChannelDifference:originalDiff/(measured*4),alphaBBox:[minX,minY,maxX-minX+1,maxY-minY+1],lowestOpaquePixel:maxY,visibleGameHeight:(maxY-minY+1)*.34});
}
if(rows.some(x=>x.sharedHeadDifferingPixels!==0))throw Error('Reused-face pixels differ');
if(rows.some(x=>x.lowestOpaquePixel>461))throw Error('Foot pixels extend below common baseline');
writeFileSync(path.join(root,'measurements.json'),JSON.stringify({faceRegion:[300,104,56,67],headBob:offsets,rows,interpretation:'The identical head proof covers a face crop; it does not claim anatomical gait correctness, identical body volume, or exact approved-widget facial likeness.'},null,2)+'\n');
console.log(JSON.stringify({sharedHeadPixelsEqual:true,frames:rows.length,footBottomRange:[Math.min(...rows.map(x=>x.lowestOpaquePixel)),Math.max(...rows.map(x=>x.lowestOpaquePixel))],visibleGameHeightRange:[Math.min(...rows.map(x=>x.visibleGameHeight)),Math.max(...rows.map(x=>x.visibleGameHeight))]},null,2));
