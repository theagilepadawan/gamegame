# Nicolai sprite fidelity lab

Isolated art and animation experiment, 2 November 2026. These assets are **not installed in the game**. The production runner atlas, gameplay animations, engine, and release files were not changed by this experiment.

## Finding

The proposed drawings bring Nicolai substantially closer to the approved invitation widget: warm outlined cartoon skin, a relaxed closed-mouth expression, short gray hair, blue windowpane jacket, open blue shirt, tan trousers, and brown leather shoes. They read clearly at the existing gameplay scale. The likeness remains an interpretation: the new three-quarter running face is slimmer and turned farther right than the approved widget portrait.

The run is a useful style and motion prototype, **not a production-ready animation**. The shoulders and torso narrow noticeably in passing poses 2 and 6. Near/far leg ownership is ambiguous across the two halves of the cycle, and the stance phase does not sustain enough backward foot travel. Reusing one head removes face morphing but does not repair those body and gait issues. A next production pass should rig one approved body/head with consistent limb lengths and explicit foot contacts, or correct each keyframe against that rig before adding inbetweens.

Jump and slide were deliberately not expanded because the run has not passed that quality bar. No established gameplay animation has been replaced.

## Reference provenance

- Latest delivered reference: `/workspace/Nicolai-Invite-Wave-Widget.zip`, dated 31 October 2026 at 06:59 UTC. SHA-256: `bac0f6c7cc0ef9aaec83240a79f2239c5fd89ca9e19624c9e7ffdf039f438475`.
- Approved drawing: `/workspace/gamegame/widget/art/cartoon/frames/wave-0.png`, copied unchanged to `reference/approved-wave-0.png`. Native **448 × 544** pixels. SHA-256: `85d6164a9f79315955871ccca981ad6e5365c4e268f8e146503d4edeacbf6f0d`.
- Final widget rig: `/workspace/gamegame/widget/assets/wave/rig.json`, copied to `reference/approved-wave-rig.json`. It keeps head, torso, sleeve, and shoulder fixed; only the original hand rotates at the wrist by 6 degrees. That fixed artwork explains the approved wave's stable likeness. Its waving motion was not applied to the runner.
- Live runner: `assets/original-27.webp`, copied unchanged to `reference/current-nicolai-atlas.webp`. Native **2048 × 1536**, 512-pixel cells in a 4 × 3 grid. Six run keys occupy cells 0–5. Engine drawing origin is **[256, 460]**, at source scale **0.34**. Run phase is `floor(distance / 28) % 6`.

## Sources and resolution

Both imagegen originals and exact prompts are retained:

| File | Native generated size | Result |
| --- | --- | --- |
| `generated/run-v1-original.png` | 1536 × 1024 | Six poses; rejected as the main study because too many strides repeat. |
| `generated/run-v2-original.png` | 1536 × 1024 | Eight poses; used for the current prototype. |

The eight figures in pass 2 have separate alpha components, approximately 219–436 pixels wide and 461–478 pixels tall. They were extracted without redrawing, scaled **down** to approximately 75–79%, and registered into a **2048 × 1024** atlas with eight **512 × 512** cells. The larger packed atlas provides consistent origins and padding; **it does not add generated detail**.

`generated/run-registered.png` retains each generated head. `generated/run-stable-head.png` mechanically isolates the head from registered frame 0 and reuses those same pixels in every pose, with a small authored vertical bob. The reused head is the generated candidate's head, not a claim of pixel-identical reuse of the widget portrait. The mask and standalone head part are preserved for inspection.

## Review and validation

Open `../../review/sprite-fidelity-lab/index.html` through the local project server, or use the standalone `Nicolai-Sprite-Fidelity-Lab.html` in that review directory. It offers the current runner versus either proposed variant, gameplay-size and 2× views, play/pause, frame stepping, loop speed, backgrounds, and registration guides. At the default 2 cycles/second, the current six frames play at 12 fps and the eight candidate frames at 16 fps. Equal cycle duration avoids making either runner appear artificially slower. Frames are discrete with no cross-fade.

`measurements.json` records an aligned **56 × 67** face-region comparison: the reused-head variant has **zero differing pixels** across all eight frames after compensating for the authored bob. The registered original heads differ in that region. The visible candidate is approximately **120–123 logical game pixels tall**. Lowest opaque shoe pixels range from y451 to y458, leaving the intended small airborne lift above the common y460 origin. These are registration checks, not proof of correct gait anatomy.

Independent visual review found: clear improvement in cartoon style and face readability; clean edges; no large last-to-first position jump; consistent foot plane; remaining torso-volume pulse, neck attachment changes in the unmodified variant, and incomplete near/far leg alternation. Browser verification, desktop/mobile screenshots, a 2× frame strip, and recorded comparisons live in the review directory.

To reproduce packing and measurements with Node and ImageMagick installed:

```sh
node art/sprite-fidelity-lab/pack.mjs
node art/sprite-fidelity-lab/stable-head.mjs
node art/sprite-fidelity-lab/measure.mjs
node review/sprite-fidelity-lab/build-review.mjs
```

Imagegen supplied both illustrated sheets. The scripts only isolate, resize, register, reuse an existing head part, pack, and measure those drawings. All work is confined to this art directory and `review/sprite-fidelity-lab`.
