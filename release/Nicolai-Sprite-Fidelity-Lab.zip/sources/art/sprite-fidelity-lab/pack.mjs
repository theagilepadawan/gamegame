import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const source=path.join(root,'generated/run-v2-original.png');
const [width,height]=execFileSync('magick',['identify','-format','%w %h',source],{encoding:'utf8'}).trim().split(' ').map(Number);
const rgba=execFileSync('magick',[source,'-depth','8','rgba:-'],{maxBuffer:32e6});
const labels=new Int32Array(width*height);const components=[];let id=0;
for(let p=0;p<labels.length;p++){if(labels[p]||rgba[p*4+3]<3)continue;id++;const q=[p];labels[p]=id;let minX=width,minY=height,maxX=0,maxY=0;
 for(let qi=0;qi<q.length;qi++){const k=q[qi],x=k%width,y=Math.floor(k/width);minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);for(let yy=Math.max(0,y-1);yy<=Math.min(height-1,y+1);yy++)for(let xx=Math.max(0,x-1);xx<=Math.min(width-1,x+1);xx++){const j=yy*width+xx;if(!labels[j]&&rgba[j*4+3]>=3){labels[j]=id;q.push(j);}}}
 if(q.length>30000)components.push({id,area:q.length,x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1});
}
components.sort((a,b)=>Math.floor(a.y/500)-Math.floor(b.y/500)||a.x-b.x);
if(components.length!==8)throw Error(`Expected8 separated figures, saw${components.length}`);
const headCenter=[294,616,998,1389,291,638,999,1390];
const headTop=[29,29,27,28,527,529,526,527];
const topTarget=[100,104,96,98,100,104,96,98];
const footTarget=[460,460,456,452,460,460,456,452];
const outdir=path.join(root,'generated/frames');mkdirSync(outdir,{recursive:true});
const registration=[];
for(const [f,c]of components.entries()){
 const pixels=Buffer.alloc(c.w*c.h*4);
 for(let y=0;y<c.h;y++)for(let x=0;x<c.w;x++){const p=(c.y+y)*width+c.x+x;if(labels[p]===c.id)rgba.copy(pixels,(y*c.w+x)*4,p*4,p*4+4);}
 const raw=path.join(outdir,`run-${f}-source.png`);
 execFileSync('magick',['-size',`${c.w}x${c.h}`,'-depth','8','rgba:-',raw],{input:pixels});
 const scale=(footTarget[f]-topTarget[f])/(c.y+c.h-1-headTop[f]);
 const w=Math.round(c.w*scale),h=Math.round(c.h*scale);
 const x=Math.round(320-(headCenter[f]-c.x)*scale),y=Math.round(topTarget[f]-(headTop[f]-c.y)*scale);
 const file=path.join(outdir,`run-${f}.png`);
 execFileSync('magick',['-size','512x512','canvas:none','(',raw,'-resize',`${w}x${h}!`,')','-geometry',`+${x}+${y}`,'-composite',file]);
 registration.push({frame:f,sourceComponent:c,headCenter:headCenter[f],headTop:headTop[f],scale,draw:[x,y,w,h],targetHead:[320,topTarget[f]],footTarget:footTarget[f]});
}
const args=['-size','2048x1024','canvas:none'];
for(let f=0;f<8;f++)args.push(path.join(outdir,`run-${f}.png`),'-geometry',`+${f%4*512}+${Math.floor(f/4)*512}`,'-composite');
execFileSync('magick',[...args,path.join(root,'generated/run-registered.png')]);
writeFileSync(path.join(root,'registration.json'),JSON.stringify({sourceSize:[width,height],packedSize:[2048,1024],cellSize:[512,512],origin:[256,460],gameScale:.34,frames:registration,method:'Alpha component extraction; uniform scale within each pose; common head center and measured shoe contact. No drawing or AI inbetweens during packing. Original generator sheet preserved.'},null,2)+'\n');
console.log(JSON.stringify({frames:registration.length,packed:'generated/run-registered.png',scaleRange:[Math.min(...registration.map(x=>x.scale)),Math.max(...registration.map(x=>x.scale))]},null,2));
