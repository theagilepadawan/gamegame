import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import { chromium } from '../../node_modules/playwright/index.mjs';

// Uses system Chromium. For video recording in the managed workspace, point
// PLAYWRIGHT_BROWSERS_PATH at a cache with ffmpeg-1011/ffmpeg-linux linked to
// /usr/bin/ffmpeg; no browser or package downloads are needed.

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
await fs.mkdir(path.join(here, 'frames'), { recursive: true });
const server = http.createServer(async (req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, 'http://local').pathname);
  const target = path.resolve(root, '.' + pathname);
  if (!target.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
  try {
    res.setHeader('Content-Type', target.endsWith('.html') ? 'text/html' : target.endsWith('.png') ? 'image/png' : target.endsWith('.webp') ? 'image/webp' : 'application/octet-stream');
    res.end(await fs.readFile(target));
  } catch { res.writeHead(404).end('Missing'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const url = 'http://127.0.0.1:' + server.address().port + '/review/sprite-fidelity-lab/index.html';
const errors = [];
let report;
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 1000 }, deviceScaleFactor: 1, recordVideo: { dir: path.join(here, 'video'), size: { width: 1280, height: 1000 } } });
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(url);
  await page.waitForFunction(() => spriteLab.snapshot().loaded.current && spriteLab.snapshot().loaded.candidate);
  await page.evaluate(() => { spriteLab.setPlaying(false); spriteLab.setFrame(0); });
  const initial = await page.evaluate(() => spriteLab.snapshot());
  assert.equal(initial.frameCount, 8);
  assert.equal(initial.currentFps, 12);
  assert.equal(initial.candidateFps, 16);
  assert.equal(initial.cyclesPerSecond, 2);
  assert.equal(initial.candidateVariant, 'stable');
  assert.deepEqual(initial.errors, []);
  await page.screenshot({ path: path.join(here, 'desktop-comparison.png'), fullPage: true });
  for (let frame = 0; frame < 8; frame++) {
    await page.evaluate(frame => spriteLab.setFrame(frame), frame);
    await page.locator('#candidate-zoom').screenshot({ path: path.join(here, 'frames', 'candidate-' + frame + '.png') });
    await page.locator('#current-zoom').screenshot({ path: path.join(here, 'frames', 'current-at-phase-' + frame + '.png') });
  }
  await page.evaluate(() => spriteLab.setVariant('registered'));
  assert.equal((await page.evaluate(() => spriteLab.snapshot())).candidateVariant, 'registered');
  await page.evaluate(() => spriteLab.setFrame(0));
  await page.screenshot({ path: path.join(here, 'desktop-registered-comparison.png'), fullPage: true });
  await page.evaluate(() => spriteLab.setVariant('stable'));
  await page.evaluate(() => spriteLab.setFrame(7));
  await page.locator('#next').click();
  assert.equal((await page.evaluate(() => spriteLab.snapshot())).frame, 0, 'Last-to-first wrap');
  await page.locator('#previous').click();
  assert.equal((await page.evaluate(() => spriteLab.snapshot())).frame, 7, 'First-to-last wrap');
  await page.locator('#guides').click();
  assert.equal(await page.locator('#guides').getAttribute('aria-pressed'), 'true');
  await page.selectOption('#background', 'dark');
  await page.evaluate(() => spriteLab.setFrame(0));
  await page.screenshot({ path: path.join(here, 'desktop-guides-dark.png'), fullPage: true });
  await page.evaluate(() => { spriteLab.setGuides(false); spriteLab.setBackground('light'); spriteLab.setFrame(0); spriteLab.setPlaying(true); });
  await page.waitForTimeout(4200);
  const played = await page.evaluate(() => spriteLab.snapshot());
  assert.ok(played.cycles >= 6, 'Animation advances through several complete loops');
  await page.selectOption('#speed', '1');
  await page.waitForTimeout(4000);
  const slow = await page.evaluate(() => spriteLab.snapshot());
  assert.equal(slow.currentFps, 6);
  assert.equal(slow.candidateFps, 8);
  await page.evaluate(() => spriteLab.setPlaying(false));
  const videoPath = await page.video().path();
  await context.close();
  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, reducedMotion: 'reduce' });
  mobile.on('pageerror', error => errors.push(error.message));
  await mobile.goto(url);
  await mobile.waitForFunction(() => spriteLab.snapshot().loaded.current && spriteLab.snapshot().loaded.candidate);
  const reduced = await mobile.evaluate(() => spriteLab.snapshot());
  assert.equal(reduced.playing, false, 'Reduced-motion review starts paused');
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'No mobile horizontal overflow');
  await mobile.screenshot({ path: path.join(here, 'mobile-comparison.png'), fullPage: true });
  await mobile.goto(url.replace('index.html', 'Nicolai-Sprite-Fidelity-Lab.html'));
  await mobile.waitForFunction(() => spriteLab.snapshot().loaded.current && spriteLab.snapshot().loaded.candidate);
  await mobile.evaluate(() => spriteLab.setVariant('registered'));
  const standalone = await mobile.evaluate(() => ({ loaded: spriteLab.snapshot().loaded, errors: spriteLab.snapshot().errors, variant: spriteLab.snapshot().candidateVariant, imageSourcesEmbedded: Object.values(spriteLab.config).every(atlas => atlas.src.startsWith('data:')) }));
  assert.equal(standalone.imageSourcesEmbedded, true);
  assert.equal(standalone.loaded.candidate, true);
  assert.deepEqual(standalone.errors, []);
  assert.deepEqual(errors, []);
  report = { passed: true, initial, completedLoops: played.cycles, slowerPlayback: { currentFps: slow.currentFps, candidateFps: slow.candidateFps }, mobile: { width: 390, reducedMotionPaused: !reduced.playing, horizontalOverflow: false }, standalone, errors, videoPath };
  await fs.writeFile(path.join(here, 'verification.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ passed: report.passed, currentFps: initial.currentFps, candidateFps: initial.candidateFps, completedLoops: played.cycles, errors, videoPath }, null, 2));
} finally {
  await browser.close();
  await new Promise(resolve => server.close(resolve));
}
