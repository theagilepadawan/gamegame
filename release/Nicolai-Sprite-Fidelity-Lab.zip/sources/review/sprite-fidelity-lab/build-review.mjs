import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
let html = await fs.readFile(path.join(here, 'index.html'), 'utf8');
const references = [...new Set(html.match(/\.\.\/\.\.\/art\/sprite-fidelity-lab\/[\w/.-]+\.(?:png|webp)/g))];
for (const reference of references) {
  const file = await fs.readFile(path.resolve(here, reference));
  const mime = reference.endsWith('.webp') ? 'image/webp' : 'image/png';
  html = html.replaceAll(reference, 'data:' + mime + ';base64,' + file.toString('base64'));
}
if (/\.\.\/\.\.\/art\/sprite-fidelity-lab\//.test(html)) throw new Error('Unembedded artwork reference');
const destination = path.join(here, 'Nicolai-Sprite-Fidelity-Lab.html');
await fs.writeFile(destination, html);
console.log(JSON.stringify({ destination, embeddedImages: references.length, bytes: Buffer.byteLength(html) }, null, 2));
