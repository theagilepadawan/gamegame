# Latest user direction

## Current authority: version 1.11

The user rejected v1.10's lag, traffic direction and reinterpreted city layers. The current build restores the **actual v1.6.0 Downtown and Midtown renderer, composition, parallax, camera and curbs**, with only six native venue-detail patches inside the original architecture. Added traffic and replacement panoramas are removed. Full 505 blue glass and the office host remain. Central Park keeps its original painting, with deliberate seating groves and grounded bench footings. Two late Midtown overheads gently rise and fall; current Endless generation and chapter-map miniatures remain.

Use `game/docs/verification.md`, `game/scripts/scenery.js`, `game/scripts/venue-details.js` and the current native location index. The broader cartoon finance-prop pass is a separate proposal in `game/docs/finance-props-direction.md`; it has not been implemented as new finished art. Earlier directions below explain history and do not override this restoration.

## Historical direction


These requests supplement the earlier proposed slate. They describe future cutscene production, not features already implemented in the playable game.

## Intro reference video

The user wants the intro, tracked as **LR-OP-01**, to follow a video they will attach to the external production session. That video has not been supplied in this workspace. Inspect it before choosing animation treatment, pacing, camera language or transitions; do not invent its style. Preserve Nicolai's likeness, costume and the game's NBIM identity.

The suggested brief provided in chat is an 8–12-second Lower Manhattan opening: Nicolai prepares to run, sets off toward screen right, and the title THE LONG RUN resolves into the first course. This duration and staging are suggestions; the forthcoming reference video should guide the actual treatment. This supersedes the earlier six-second intro suggestion where they conflict.

## Running-shoe transition

The user explicitly wants Nicolai to receive the exact trainers used by his Central Park sprites **after completing the second course, Midtown, and before Central Park**. This beat is tracked as **LR-SH-01**. These are running shoes, not replacement trousers. Preserve the existing Park footwear artwork and its appearance in gameplay. The source sheets are `game/assets/original-17.webp` and `original-18.webp`; the runtime already selects them for Park, but no shoe-receiving cinematic exists.

Suggested staging from the chat brief: outside 505's blue/cyan lobby, the office host presents a shoebox. Nicolai opens it, smiles, changes out of his formal shoes and tightens the trainers' laces. One light test step leads into his jog toward Central Park. Aim for 6–8 seconds with calm, deliberate motion. The office staging, length and optional caption “Investing in the long run” are proposals, not mandatory details specified by the user.

Keep this transition compatible with the existing next-chapter action, history reveal and unlock progression. Do not interrupt the still-active second course or add a compulsory film to every retry.

## Current New York art direction

The user wants the warmth and movement of their earlier supplied city backdrop, retaining current gameplay and detailed Easter eggs. A prior agent incorrectly associated the user's “1.6.0” label with repository commit `a551054`; that identity was not established, and its broad Downtown river/cutout composition was explicitly rejected.

Version 1.12 corrects Downtown only using the actual earlier supplied HTML (SHA-256 `9fd060927fc13512f82b18c86e9edc8cf19de59357f5874169d9e8644b263488`). Complete warm street paintings carry the skyline, façades, lamps and pavement together. Original slow scrolling/intro hold are preserved. Only inappropriate skyline towers were locally corrected. Detailed Kabin and LEI fronts sit in separate later street paintings with original foreground lamps restored in front. There is no global Downtown river layer or detached building composition. Water is confined to the original painted waterfront views behind the promenade.

Midtown/Park retain the current implementation. Keep the full blue/cyan 505 glass, revolving doors and host anchor. Current native venue files remain intact. Do not import an earlier gameplay build or regroup Easter eggs. Endless continues through anonymous street paintings without repeating WTC, the bridge or named fronts.

The chapter map now uses miniature Nicolai and Trond cropped from the approved playable atlases. They run briefly between course markers and then settle into a still pose; reduced motion uses a static change. This does not change the character art direction. Endless has a new seeded route director, continuous terrain and progressive combinations. These are gameplay changes, not newly commissioned cutscene beats.

Use `references/locations/INDEX.md` and `location-manifest.json` to open the exact native source files in `game/assets/`; large city artwork is stored once, without downsampling. Current runtime manifests and gameplay captures define final composition. `assets/props-v18/`, Central Park, existing runner sheets, audio and game systems remain. Previous scenery versions are historical references, not current production authority. Test completion and user acceptance must be stated separately.
