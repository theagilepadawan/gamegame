# Native audio sources

Each original is stored once in game/assets, byte-for-byte. Open the linked source; no recompression or removal.

| Track reference | Source | SHA-256 |
|---|---|---|
| 01-opening-theme.mp3 | [original-37.mp3](../../game/assets/original-37.mp3) | `b9e72bf64bdfca7833e91b6cc93c6a245d06603526ed841d71d0d9d3d07645d0` |
| 06-title-mellow-lounge.mp3 | [audio/title-mellow-lounge.mp3](../../game/assets/audio/title-mellow-lounge.mp3) | `c00d02e874e1ed0d387849055399abefeb07d45a93f2711b4188d8d44948ec72` |
| 02-midtown-theme.mp3 | [original-19.mp3](../../game/assets/original-19.mp3) | `0e8e5c01ac041c324b9a03064f59af9caef402c3c31c552f5c45d2eaff48e7e7` |
| 03-central-park-theme.mp3 | [original-20.mp3](../../game/assets/original-20.mp3) | `9bd0f9bfedae0664109677e6f1f090cb141ef07abc84430bd3633c2a5ac75ca4` |
| 04-nicolai-laugh.mp3 | [original-38.mp3](../../game/assets/original-38.mp3) | `259f4c7d7d28a0fc03ac60b665507d2df10a0bfd5dae0df7d9895848b829cb54` |
| 05-contrarian-pixel-adventure.mp3 | [original-39.mp3](../../game/assets/original-39.mp3) | `d8fc27a6fa989ef52fbd5c303b2d38a5609b3359ba3b2cd121456b01f3acd981` |
