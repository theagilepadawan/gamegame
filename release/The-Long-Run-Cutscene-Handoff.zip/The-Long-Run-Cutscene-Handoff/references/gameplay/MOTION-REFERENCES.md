# Optional motion recordings

The complete animations, native keyframes and renderer are included in game/.
These two earlier reference recordings are linked separately to keep the source handoff below 100 MiB.
The supplied in-game gift film and its native source remain inside this ZIP.

| Recording | Bytes | SHA-256 |
|---|---:|---|
| [Nicolai-v121-boarding.mp4](https://github.com/theagilepadawan/gamegame/raw/99df76e9292e7d04f571f5da957101b55d48ce14/release/Nicolai-v121-boarding.mp4) | 1437309 | `7a68d55a97ffe2b7a5e72abed8b81162be04f3e2663140a08aff1c4db449a221` |
| [Nicolai-v122-office-entry.mp4](https://github.com/theagilepadawan/gamegame/raw/99df76e9292e7d04f571f5da957101b55d48ce14/release/Nicolai-v122-office-entry.mp4) | 2901144 | `7d2703bf67a96dc05e7469d491c66ffd1f33c9f5f20fb180b7dc964913b4faea` |
