# Native location references

Open these exact files in the editable game tree. Each native image is stored once; no reduced substitute is used here.

The runtime manifests and storefront metadata define course order, alignment and venue spacing. Gameplay captures show their final composition.

Downtown uses the complete warm paintings and camera from the actual supplied HTML; its former global river/cutout composition is removed. Midtown remains current. Six native venue-detail crops belong inside their street façades with no independent camera.

| Location | Native pixels | Source |
|---|---:|---|
| Central Park — approved Bow Bridge | 1672×941 | [original-33.webp](../../game/assets/original-33.webp) |
| Central Park — approved Ramble | 1672×941 | [park-1.webp](../../game/assets/scenery/park-1.webp) |
| Central Park — approved Bethesda | 1672×941 | [park-2.webp](../../game/assets/scenery/park-2.webp) |
| Midtown — native street-tree transition | 1024×1536 | [city-plane-tree.webp](../../game/assets/art-v2/city-plane-tree.webp) |
| midtown-fifth | 1024×1536 | [midtown-fifth.webp](../../game/assets/art-v2/midtown-fifth.webp) |
| midtown-garden | 1024×1536 | [midtown-garden.webp](../../game/assets/art-v2/midtown-garden.webp) |
| midtown-gussy | 1024×1536 | [midtown-gussy.webp](../../game/assets/art-v2/midtown-gussy.webp) |
| midtown-joju | 1024×1536 | [midtown-joju.webp](../../game/assets/art-v2/midtown-joju.webp) |
| midtown-omars | 1024×1536 | [midtown-omars.webp](../../game/assets/art-v2/midtown-omars.webp) |
| Downtown — original warm composition with corrected skyline | 1536×1024 | [lower-manhattan.webp](../../game/assets/downtown-v112/lower-manhattan.webp) |
| construction-corner | 1024×1536 | [construction-corner.webp](../../game/assets/midtown-v15/construction-corner.webp) |
| Midtown — restored v1.6 glass-office frontage | 1024×1536 | [glass-canyon.webp](../../game/assets/midtown-v15/glass-canyon.webp) |
| limestone-cafe | 1024×1536 | [limestone-cafe.webp](../../game/assets/midtown-v15/limestone-cafe.webp) |
| Midtown — restored v1.6 dry skyline atmosphere | 1536×1024 | [dry-city-atmosphere.webp](../../game/assets/midtown-v16/dry-city-atmosphere.webp) |
| Midtown — unique Empire State / Chrysler vista | 1536×1024 | [landmark-panorama.webp](../../game/assets/midtown-v16/landmark-panorama.webp) |
| Midtown — restored v1.6 library frontage | 1024×1536 | [library-frontage.webp](../../game/assets/midtown-v16/library-frontage.webp) |
| masonry-street | 1024×1536 | [masonry-street.webp](../../game/assets/midtown-v16/masonry-street.webp) |
| City terrain — native v1.6 stone foundation | 1254×1254 | [stone-foundation.webp](../../game/assets/midtown-v16/stone-foundation.webp) |
| Downtown — Seaport street hosting Kabin | 1536×1024 | [opening-2.webp](../../game/assets/scenery/opening-2.webp) |
| Downtown — Battery street hosting LEI | 1536×1024 | [opening-3.webp](../../game/assets/scenery/opening-3.webp) |
| Downtown — anonymous Endless continuation | 1536×1024 | [opening-battery-loop.webp](../../game/assets/scenery/opening-battery-loop.webp) |
| Downtown — original painted bridge and promenade | 1536×1024 | [opening-bridge.webp](../../game/assets/scenery/opening-bridge.webp) |
| Downtown — original Tribeca approach | 1536×1024 | [opening-west.webp](../../game/assets/scenery/opening-west.webp) |
| fifth | 511×390 | [fifth.webp](../../game/assets/venue-details-v111/fifth.webp) |
| gussy | 680×338 | [gussy.webp](../../game/assets/venue-details-v111/gussy.webp) |
| joju | 525×326 | [joju.webp](../../game/assets/venue-details-v111/joju.webp) |
| kabin | 410×205 | [kabin.webp](../../game/assets/venue-details-v111/kabin.webp) |
| lei | 452×290 | [lei.webp](../../game/assets/venue-details-v111/lei.webp) |
| omars | 529×268 | [omars.webp](../../game/assets/venue-details-v111/omars.webp) |
