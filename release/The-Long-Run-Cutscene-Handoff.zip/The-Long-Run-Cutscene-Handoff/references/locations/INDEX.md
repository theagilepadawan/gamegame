# Native location references

Open these exact files in the editable game tree. Each native image is stored once; no reduced substitute is used here.

The runtime manifests and storefront metadata define course order, alignment and venue spacing. Gameplay captures show their final composition.

Downtown uses the complete warm paintings and camera from the actual supplied HTML; its former global river/cutout composition is removed. Midtown restores its original complete warm paintings with fixed vertical framing. Six native venue-detail crops belong inside their street façades with no independent camera.

| Location | Native pixels | Source |
|---|---:|---|
| Central Park — approved Bow Bridge | 1672×941 | [original-33.webp](../../game/assets/original-33.webp) |
| Central Park — approved Ramble | 1672×941 | [park-1.webp](../../game/assets/scenery/park-1.webp) |
| Central Park — approved Bethesda | 1672×941 | [park-2.webp](../../game/assets/scenery/park-2.webp) |
| Downtown — original warm composition with corrected skyline | 1536×1024 | [lower-manhattan.webp](../../game/assets/downtown-v112/lower-manhattan.webp) |
| Midtown — original Bryant Park and library, lossless master | 1672×941 | [bryant-park.webp](../../game/assets/midtown-v113/bryant-park.webp) |
| Midtown — original glass-office street, lossless master | 1672×941 | [fifth-avenue.webp](../../game/assets/midtown-v113/fifth-avenue.webp) |
| Midtown — warm ordinary restaurant street | 1672×941 | [restaurant-street.webp](../../game/assets/midtown-v113/restaurant-street.webp) |
| Midtown — original golden skyline, lossless master | 1672×941 | [skyline.webp](../../game/assets/midtown-v113/skyline.webp) |
| City terrain — current native stone foundation | 1254×1254 | [stone-foundation.webp](../../game/assets/midtown-v16/stone-foundation.webp) |
| Downtown — Seaport street hosting Kabin | 1536×1024 | [opening-2.webp](../../game/assets/scenery/opening-2.webp) |
| Downtown — Battery street hosting LEI | 1536×1024 | [opening-3.webp](../../game/assets/scenery/opening-3.webp) |
| Downtown — anonymous Endless continuation | 1536×1024 | [opening-battery-loop.webp](../../game/assets/scenery/opening-battery-loop.webp) |
| Downtown — original painted bridge and promenade | 1536×1024 | [opening-bridge.webp](../../game/assets/scenery/opening-bridge.webp) |
| Downtown — original Tribeca approach | 1536×1024 | [opening-west.webp](../../game/assets/scenery/opening-west.webp) |
| fifth | 511×390 | [fifth.webp](../../game/assets/venue-details-v111/fifth.webp) |
| gussy | 680×338 | [gussy.webp](../../game/assets/venue-details-v111/gussy.webp) |
| joju | 525×326 | [joju.webp](../../game/assets/venue-details-v111/joju.webp) |
| kabin | 410×205 | [kabin.webp](../../game/assets/venue-details-v111/kabin.webp) |
| lei | 452×290 | [lei.webp](../../game/assets/venue-details-v111/lei.webp) |
| omars | 529×268 | [omars.webp](../../game/assets/venue-details-v111/omars.webp) |
