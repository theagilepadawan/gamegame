# Native location references

Open these exact files in the editable game tree. Each native image is stored once; no reduced substitute is used here.

The runtime manifests and storefront metadata define course order, alignment and venue spacing. Gameplay captures show their final composition.

| Location | Native pixels | Source |
|---|---:|---|
| Central Park — approved Bow Bridge | 1672×941 | [original-33.webp](../../game/assets/original-33.webp) |
| Central Park — approved Ramble | 1672×941 | [park-1.webp](../../game/assets/scenery/park-1.webp) |
| Central Park — approved Bethesda | 1672×941 | [park-2.webp](../../game/assets/scenery/park-2.webp) |
| downtown-00 | 1024×1536 | [downtown-00.webp](../../game/assets/scenery-v19/downtown-00.webp) |
| Downtown — One World Trade Center | 1024×1536 | [downtown-01.webp](../../game/assets/scenery-v19/downtown-01.webp) |
| Downtown — Wall Street | 1024×1536 | [downtown-02.webp](../../game/assets/scenery-v19/downtown-02.webp) |
| Downtown — bounded harbor and Brooklyn Bridge | 1024×1536 | [downtown-03.webp](../../game/assets/scenery-v19/downtown-03.webp) |
| downtown-04 | 1024×1536 | [downtown-04.webp](../../game/assets/scenery-v19/downtown-04.webp) |
| Downtown — Kabin | 1024×1536 | [downtown-05.webp](../../game/assets/scenery-v19/downtown-05.webp) |
| downtown-06 | 1024×1536 | [downtown-06.webp](../../game/assets/scenery-v19/downtown-06.webp) |
| downtown-07 | 1024×1536 | [downtown-07.webp](../../game/assets/scenery-v19/downtown-07.webp) |
| downtown-08 | 1024×1536 | [downtown-08.webp](../../game/assets/scenery-v19/downtown-08.webp) |
| downtown-09 | 1024×1536 | [downtown-09.webp](../../game/assets/scenery-v19/downtown-09.webp) |
| downtown-10 | 1024×1536 | [downtown-10.webp](../../game/assets/scenery-v19/downtown-10.webp) |
| Downtown — LEI | 1024×1536 | [downtown-11.webp](../../game/assets/scenery-v19/downtown-11.webp) |
| downtown-00 | 809×1942 | [downtown-00.webp](../../game/assets/scenery-v19/joins/downtown-00.webp) |
| Downtown — One World Trade Center | 809×1942 | [downtown-01.webp](../../game/assets/scenery-v19/joins/downtown-01.webp) |
| Downtown — Wall Street | 809×1942 | [downtown-02.webp](../../game/assets/scenery-v19/joins/downtown-02.webp) |
| Downtown — bounded harbor and Brooklyn Bridge | 809×1942 | [downtown-03.webp](../../game/assets/scenery-v19/joins/downtown-03.webp) |
| downtown-04-06 | 809×1942 | [downtown-04-06.webp](../../game/assets/scenery-v19/joins/downtown-04-06.webp) |
| downtown-04 | 809×1942 | [downtown-04.webp](../../game/assets/scenery-v19/joins/downtown-04.webp) |
| Downtown — Kabin | 809×1942 | [downtown-05.webp](../../game/assets/scenery-v19/joins/downtown-05.webp) |
| downtown-06 | 809×1942 | [downtown-06.webp](../../game/assets/scenery-v19/joins/downtown-06.webp) |
| downtown-07 | 809×1942 | [downtown-07.webp](../../game/assets/scenery-v19/joins/downtown-07.webp) |
| downtown-08 | 809×1942 | [downtown-08.webp](../../game/assets/scenery-v19/joins/downtown-08.webp) |
| downtown-09 | 809×1942 | [downtown-09.webp](../../game/assets/scenery-v19/joins/downtown-09.webp) |
| downtown-10-04 | 809×1942 | [downtown-10-04.webp](../../game/assets/scenery-v19/joins/downtown-10-04.webp) |
| downtown-10 | 809×1942 | [downtown-10.webp](../../game/assets/scenery-v19/joins/downtown-10.webp) |
| downtown-11-04 | 809×1942 | [downtown-11-04.webp](../../game/assets/scenery-v19/joins/downtown-11-04.webp) |
| midtown-00 | 809×1942 | [midtown-00.webp](../../game/assets/scenery-v19/joins/midtown-00.webp) |
| Midtown — Chrysler Building | 809×1942 | [midtown-01.webp](../../game/assets/scenery-v19/joins/midtown-01.webp) |
| Midtown — Empire State Building | 809×1942 | [midtown-02.webp](../../game/assets/scenery-v19/joins/midtown-02.webp) |
| Midtown — Bryant Park / library | 809×1942 | [midtown-03.webp](../../game/assets/scenery-v19/joins/midtown-03.webp) |
| midtown-04 | 809×1942 | [midtown-04.webp](../../game/assets/scenery-v19/joins/midtown-04.webp) |
| Midtown — JOJU | 746×2107 | [midtown-05.webp](../../game/assets/scenery-v19/joins/midtown-05.webp) |
| midtown-06 | 809×1942 | [midtown-06.webp](../../game/assets/scenery-v19/joins/midtown-06.webp) |
| midtown-07 | 724×2172 | [midtown-07.webp](../../game/assets/scenery-v19/joins/midtown-07.webp) |
| Midtown — Omar's | 747×2106 | [midtown-08.webp](../../game/assets/scenery-v19/joins/midtown-08.webp) |
| midtown-09 | 809×1942 | [midtown-09.webp](../../game/assets/scenery-v19/joins/midtown-09.webp) |
| midtown-10 | 724×2172 | [midtown-10.webp](../../game/assets/scenery-v19/joins/midtown-10.webp) |
| Midtown — Uncle Gussy's | 724×2172 | [midtown-11.webp](../../game/assets/scenery-v19/joins/midtown-11.webp) |
| midtown-12 | 809×1942 | [midtown-12.webp](../../game/assets/scenery-v19/joins/midtown-12.webp) |
| midtown-13 | 724×2172 | [midtown-13.webp](../../game/assets/scenery-v19/joins/midtown-13.webp) |
| Midtown — complete 505 Fifth glass entrance | 747×2106 | [midtown-14.webp](../../game/assets/scenery-v19/joins/midtown-14.webp) |
| midtown-00 | 1024×1536 | [midtown-00.webp](../../game/assets/scenery-v19/midtown-00.webp) |
| Midtown — Chrysler Building | 1024×1536 | [midtown-01.webp](../../game/assets/scenery-v19/midtown-01.webp) |
| Midtown — Empire State Building | 1024×1536 | [midtown-02.webp](../../game/assets/scenery-v19/midtown-02.webp) |
| Midtown — Bryant Park / library | 1024×1536 | [midtown-03.webp](../../game/assets/scenery-v19/midtown-03.webp) |
| midtown-04 | 1024×1536 | [midtown-04.webp](../../game/assets/scenery-v19/midtown-04.webp) |
| Midtown — JOJU | 1024×1536 | [midtown-05.webp](../../game/assets/scenery-v19/midtown-05.webp) |
| midtown-06 | 1024×1536 | [midtown-06.webp](../../game/assets/scenery-v19/midtown-06.webp) |
| midtown-07 | 1024×1536 | [midtown-07.webp](../../game/assets/scenery-v19/midtown-07.webp) |
| Midtown — Omar's | 1024×1536 | [midtown-08.webp](../../game/assets/scenery-v19/midtown-08.webp) |
| midtown-09 | 1024×1536 | [midtown-09.webp](../../game/assets/scenery-v19/midtown-09.webp) |
| midtown-10 | 1024×1536 | [midtown-10.webp](../../game/assets/scenery-v19/midtown-10.webp) |
| Midtown — Uncle Gussy's | 1024×1536 | [midtown-11.webp](../../game/assets/scenery-v19/midtown-11.webp) |
| midtown-12 | 1024×1536 | [midtown-12.webp](../../game/assets/scenery-v19/midtown-12.webp) |
| midtown-13 | 1024×1536 | [midtown-13.webp](../../game/assets/scenery-v19/midtown-13.webp) |
| Midtown — complete 505 Fifth glass entrance | 1024×1536 | [midtown-14.webp](../../game/assets/scenery-v19/midtown-14.webp) |
| midtown-15 | 1024×1536 | [midtown-15.webp](../../game/assets/scenery-v19/midtown-15.webp) |
