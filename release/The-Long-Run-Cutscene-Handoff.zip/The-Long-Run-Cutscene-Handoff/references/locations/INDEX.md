# Native location references

Open these exact files in the editable game tree. Each native image is stored once; no reduced substitute is used here.

The runtime manifests and storefront metadata define course order, alignment and venue spacing. Gameplay captures show their final composition.

Downtown and Midtown use the exact v1.6 architecture, composition and movement. Six native venue-detail crops are painted once inside their original frontages by `venue-details.js`; they have no independent camera.

| Location | Native pixels | Source |
|---|---:|---|
| Central Park — approved Bow Bridge | 1672×941 | [original-33.webp](../../game/assets/original-33.webp) |
| Central Park — approved Ramble | 1672×941 | [park-1.webp](../../game/assets/scenery/park-1.webp) |
| Central Park — approved Bethesda | 1672×941 | [park-2.webp](../../game/assets/scenery/park-2.webp) |
| Midtown — native street-tree transition | 1024×1536 | [city-plane-tree.webp](../../game/assets/art-v2/city-plane-tree.webp) |
| downtown-atmosphere | 1536×1024 | [downtown-atmosphere.webp](../../game/assets/art-v2/downtown-atmosphere.webp) |
| downtown-block | 1024×1536 | [downtown-block.webp](../../game/assets/art-v2/downtown-block.webp) |
| downtown-bridge-wide | 2171×724 | [downtown-bridge-wide.webp](../../game/assets/art-v2/downtown-bridge-wide.webp) |
| downtown-kabin | 1024×1536 | [downtown-kabin.webp](../../game/assets/art-v2/downtown-kabin.webp) |
| downtown-lei | 1024×1536 | [downtown-lei.webp](../../game/assets/art-v2/downtown-lei.webp) |
| downtown-seaport | 1024×1536 | [downtown-seaport.webp](../../game/assets/art-v2/downtown-seaport.webp) |
| downtown-tribeca | 1024×1536 | [downtown-tribeca.webp](../../game/assets/art-v2/downtown-tribeca.webp) |
| downtown-wallstreet | 1024×1536 | [downtown-wallstreet.webp](../../game/assets/art-v2/downtown-wallstreet.webp) |
| downtown-waterfront | 1024×1536 | [downtown-waterfront.webp](../../game/assets/art-v2/downtown-waterfront.webp) |
| downtown-wtc | 1024×1536 | [downtown-wtc.webp](../../game/assets/art-v2/downtown-wtc.webp) |
| midtown-fifth | 1024×1536 | [midtown-fifth.webp](../../game/assets/art-v2/midtown-fifth.webp) |
| midtown-garden | 1024×1536 | [midtown-garden.webp](../../game/assets/art-v2/midtown-garden.webp) |
| midtown-gussy | 1024×1536 | [midtown-gussy.webp](../../game/assets/art-v2/midtown-gussy.webp) |
| midtown-joju | 1024×1536 | [midtown-joju.webp](../../game/assets/art-v2/midtown-joju.webp) |
| midtown-omars | 1024×1536 | [midtown-omars.webp](../../game/assets/art-v2/midtown-omars.webp) |
| construction-corner | 1024×1536 | [construction-corner.webp](../../game/assets/midtown-v15/construction-corner.webp) |
| Midtown — restored v1.6 glass-office frontage | 1024×1536 | [glass-canyon.webp](../../game/assets/midtown-v15/glass-canyon.webp) |
| limestone-cafe | 1024×1536 | [limestone-cafe.webp](../../game/assets/midtown-v15/limestone-cafe.webp) |
| Midtown — restored v1.6 dry skyline atmosphere | 1536×1024 | [dry-city-atmosphere.webp](../../game/assets/midtown-v16/dry-city-atmosphere.webp) |
| Midtown — unique Empire State / Chrysler vista | 1536×1024 | [landmark-panorama.webp](../../game/assets/midtown-v16/landmark-panorama.webp) |
| Midtown — restored v1.6 library frontage | 1024×1536 | [library-frontage.webp](../../game/assets/midtown-v16/library-frontage.webp) |
| masonry-street | 1024×1536 | [masonry-street.webp](../../game/assets/midtown-v16/masonry-street.webp) |
| City terrain — native v1.6 stone foundation | 1254×1254 | [stone-foundation.webp](../../game/assets/midtown-v16/stone-foundation.webp) |
| fifth | 511×390 | [fifth.webp](../../game/assets/venue-details-v111/fifth.webp) |
| gussy | 680×338 | [gussy.webp](../../game/assets/venue-details-v111/gussy.webp) |
| joju | 525×326 | [joju.webp](../../game/assets/venue-details-v111/joju.webp) |
| kabin | 410×205 | [kabin.webp](../../game/assets/venue-details-v111/kabin.webp) |
| lei | 452×290 | [lei.webp](../../game/assets/venue-details-v111/lei.webp) |
| omars | 529×268 | [omars.webp](../../game/assets/venue-details-v111/omars.webp) |
