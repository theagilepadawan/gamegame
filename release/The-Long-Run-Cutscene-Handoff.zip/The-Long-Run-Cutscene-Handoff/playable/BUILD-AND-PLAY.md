# Build and play this complete source handoff

This ZIP contains all editable source, native artwork, tests, audio and production
references. The duplicate compiled HTML was omitted to keep the archive below
100 MiB while retaining the full native asset quality. The separately delivered
`The-Long-Run-NBIM.zip` contains the ready-to-play HTML.

## Recreate the exact standalone game

Install Node.js 20 or newer if needed. No npm install or network access is needed
for this build. From the handoff's `game/` directory, run:

```sh
node build.mjs ../playable/The-Long-Run-NBIM.html
```

The packaging process ran this build from the staged source and verified its
output against the current release. Expected output:

- Version: `1.27.0`
- File: `The-Long-Run-NBIM.html`
- Bytes: `73827607`
- SHA-256: `c4230ade05656297466872812b225130e9de215f18b83ce5f5bda734e9e33f91`

The same hash is recorded in `EXPECTED-STANDALONE-SHA256.txt`. After building,
run `shasum -a 256 -c EXPECTED-STANDALONE-SHA256.txt` from `playable/`, or compare
the output of PowerShell `Get-FileHash -Algorithm SHA256` with the hash above.

Open the generated HTML in a current browser. To play directly from the editable
source instead, run `node serve.mjs` inside `game/` and open the printed local URL.
Browser tests use Playwright and require the separate test dependency setup;
playing or building the game does not.

`HANDOFF-METADATA.json` records `playableIncluded: false`, the verified rebuild
and every build-input hash. `FILES-SHA256.json` covers all files in this ZIP.
