# Nicolai — a little invitation

A miniature Nicolai leans into the page from the right and waves beside the
speech bubble **“Want to play a game?”** His approved likeness is redrawn with
clear cartoon contours, painted color planes and the game's blue checked
blazer, open blue shirt and tan trousers.

Nicolai gives one restrained 1.6-second greeting, then holds a quiet raised-hand
pose. The original approved drawing supplies the face, body and full-size arm;
its sleeve color, checks and proportions are retained exactly. Only the original
hand moves, with a small eased wrist wave. The sleeve, shoulder, head and torso
remain fixed throughout. A Canvas 2D player handles that isolated hand, while
GSAP 3.13 gives the entrance and speech bubble a gentle deceleration. The actual
link and dismiss control remain ordinary HTML.

## Preview

Open `Nicolai-Invite.html` in your browser. This self-contained demo includes all
artwork and animation code; it works offline. “Replay Nicolai” repeats the
greeting. Its destination is deliberately a placeholder (`#game`).

## Put Nicolai on your page

Upload `nicolai-invite.min.js` to your site, then add this before `</body>`:

```html
<script src="/widgets/nicolai-invite.min.js"></script>
<script>
  const nicolai = NicolaiInvite.mount({
    href: '#game' // Replace with your game URL, for example '/play/'.
  });
</script>
```

The JavaScript file includes GSAP, styles and transparent art. It makes no
additional network requests and requires no host-page framework. Shadow DOM
keeps its styles separate from the page. The transparent area is click-through.

For a module-based project, use `nicolai-invite.mjs` instead:

```js
import { mount } from './nicolai-invite.mjs';
const nicolai = mount({ href: '/play/' });
// During route/component cleanup:
nicolai.destroy();
```

Use `mount` inside your component's mount/effect hook, then call `destroy()` from
its cleanup hook. The bundle must run in a browser, after the body exists.

## Options

| Option | Default | Purpose |
| --- | --- | --- |
| `href` | `'#game'` | Relative path, page anchor, or http(s) game URL. |
| `message` | `'Want to play a game?'` | Plain-text speech bubble; keep it short. |
| `delay` | `0.65` | Seconds before the first entrance, limited to 0–30. |
| `bottom` | responsive default | CSS length, such as `'88px'`, to clear your site’s controls. |
| `target` | `'_self'` | Use `'_blank'` to open a new tab. |
| `parent` | `document.body` | Optional mount element; body is best for fixed positioning. |

Both the character and bubble open the same link. The dismiss button and Escape
while focused close it for the lifetime of that instance. A new page load can
show it again; no cookies, storage, analytics or audio are used.

The instance exposes `element`, `ready`, `replay()`, `dismiss()`, `destroy()` and
`state`. Repeated mounts in the same parent clean up the old instance. `replay()`
does not reopen a dismissed widget; destroy and mount again if you want that.
Set the CSS property `--nicolai-z-index` on `instance.element` if you need a
different stacking order (default 1000). Use `bottom` to avoid consent banners,
chat buttons or mobile navigation on your page.

The entrance is followed by one wave and a still resting pose. There are no
beckoning gestures or automatic repeat waves. Hover or keyboard focus can
replay the greeting after a 12-second cooldown, once the current gesture has
finished. The demo's replay button and `replay()` remain available explicitly.
Animations pause in hidden tabs. Reduced-motion preferences display a still
Nicolai and the bubble immediately; preference changes are honored live.

## Build from source

From this folder with Node.js 20+:

```sh
npm ci
npm run build
npm start
```

In the downloadable ZIP, run these commands from the `source/` folder. Preview
at `http://localhost:4180`. Build output is in `release/`. The game itself is not
modified by this widget. `assets/` contains the optimized transparent layers and
their assembly geometry. The project's working `art/` directory retains the
generated originals and reference photos; those are omitted from the installable
ZIP. Both browser bundles contain all the artwork they need. The original body,
hand and cuff layers, geometry and timing are in `assets/wave/`; the renderer is
`src/character-animation.js`. Canvas resolution follows device pixel density,
up to 3×, independently of the CSS entrance transforms.

The widget uses inline shadow styles and data images; if your site has a Content
Security Policy, permit these for the widget or adapt the source to your policy.
See `THIRD-PARTY-NOTICES.md` for the GSAP license.
