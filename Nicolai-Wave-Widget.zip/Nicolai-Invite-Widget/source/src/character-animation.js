import { gsap } from 'gsap';
import rigData from '../assets/wave/rig.json';
import bodyImage from '../assets/wave/body.webp';
import handImage from '../assets/wave/hand.webp';
import cuffImage from '../assets/wave/cuff.webp';

export const CHARACTER_SIZE = Object.freeze(rigData.canvas ?? [448, 544]);
const positive = (value, fallback) => Number.isFinite(Number(value)) && Number(value) > 0 ? Number(value) : fallback;

/** The approved drawing stays fixed. Only its original hand can move. */
function prepareRig(data) {
  const width = positive(data.canvas?.[0], 448);
  const height = positive(data.canvas?.[1], 544);
  const columns = positive(data.cell?.columns, 4);
  const cellWidth = positive(data.cell?.width, width);
  const cellHeight = positive(data.cell?.height, height);
  const entries = Array.isArray(data.frames)
    ? data.frames.map((value, index) => [value.name ?? String(index), value])
    : Object.entries(data.frames ?? {});
  if (!entries.length) throw new TypeError('The character rig has no hand frames.');
  const names = new Map();
  const frames = entries.map(([name, value], index) => {
    names.set(name, index);
    const draw = value.draw ?? {};
    return {
      name, image: value.image ?? 0,
      x: value.x ?? index % columns * cellWidth,
      y: value.y ?? Math.floor(index / columns) * cellHeight,
      width: positive(value.width ?? value.w, cellWidth),
      height: positive(value.height ?? value.h, cellHeight),
      drawX: draw.x ?? value.offset?.[0] ?? 0,
      drawY: draw.y ?? value.offset?.[1] ?? 0,
      drawWidth: positive(draw.width, width),
      drawHeight: positive(draw.height, height),
      phase: value.phase ?? 'gesture',
      layer: value.layer === 'back' ? 'back' : 'front',
      duration: positive(value.duration, 1 / positive(data.fps, 15)),
    };
  });
  const lookup = value => {
    const index = typeof value === 'number' ? value : names.get(value);
    if (!Number.isInteger(index) || !frames[index]) throw new TypeError(`Unknown character hand frame: ${String(value)}`);
    return index;
  };
  const rest = lookup(data.restFrame ?? entries[0][0]);
  const sequences = {};
  for (const [name, value] of Object.entries(data.sequences ?? {})) {
    const items = Array.isArray(value) ? value : value.frames;
    if (!Array.isArray(items) || !items.length) continue;
    let total = 0;
    const stops = items.map(item => {
      const entry = typeof item === 'object' ? item : { frame: item };
      const frame = lookup(entry.frame ?? entry.name);
      const start = total;
      total += positive(entry.duration, frames[frame].duration);
      return { frame, start, end: total, phase: entry.phase ?? frames[frame].phase,
        waveDegrees: Number(entry.motion?.waveDegrees) || 0 };
    });
    sequences[name] = { stops, duration: total, loop: value.loop === true };
  }
  sequences.idle ??= { stops: [{ frame: rest, start: 0, end: 5, phase: 'rest', waveDegrees: 0 }], duration: 5, loop: true };
  sequences.greeting ??= sequences.wave ?? sequences.idle;
  sequences.wave ??= sequences.greeting;
  const body = data.body ?? {};
  return {
    width, height, frames, sequences, rest,
    pivot: data.pivot ?? [116, 205],
    body: { x: body.x ?? 0, y: body.y ?? 0, width: positive(body.width, width), height: positive(body.height, height) },
    overlays: data.overlays ?? [],
  };
}

function stopAt(sequence, seconds) {
  for (const stop of sequence.stops) if (seconds < stop.end) return stop;
  return sequence.stops[sequence.stops.length - 1];
}

/** Original head, jacket and full-size sleeve with one gentle wrist wave. */
export function createCharacter(canvas, options = {}) {
  if (!canvas?.getContext) throw new TypeError('A canvas element is required.');
  const context = canvas.getContext('2d', { alpha: true });
  if (!context) throw new Error('This browser cannot create a 2D character canvas.');
  const rig = prepareRig(options.rig ?? options.atlas ?? rigData);
  const body = new Image();
  body.decoding = 'async';
  body.src = options.bodyURL ?? bodyImage;
  const cuff = new Image();
  cuff.decoding = 'async';
  cuff.src = options.cuffURL ?? cuffImage;
  const sources = options.handURL ?? options.atlasURL ?? handImage;
  const hands = (Array.isArray(sources) ? sources : [sources]).map(url => {
    const image = new Image();
    image.decoding = 'async';
    image.src = url;
    return image;
  });
  // Cache the base at display resolution: no varying full-body resampling.
  const base = document.createElement('canvas');
  const baseContext = base.getContext('2d', { alpha: true });
  const overlay = document.createElement('canvas');
  const overlayContext = overlay.getContext('2d', { alpha: true });
  if (!baseContext || !overlayContext) throw new Error('This browser cannot create character layers.');
  let status = 'loading';
  let destroyed = false;
  let manualPause = false;
  let hidden = document.hidden;
  let reduced = Boolean(options.reducedMotion);
  let subscribed = false;
  let sequenceName = 'idle';
  let sequence = rig.sequences.idle;
  let sequenceTime = 0;
  let clock = 0;
  let currentFrame = rig.rest;
  let phase = 'rest';
  let drawCount = 0;
  let lastStamp = '';
  let dpr = 0;
  let baseDirty = true;
  let handRotation = 0;
  let looping = true;
  let complete = null;
  const paused = () => manualPause || hidden || reduced;

  function fit() {
    const bounds = canvas.getBoundingClientRect();
    const width = canvas.clientWidth || bounds.width || rig.width;
    const height = canvas.clientHeight || bounds.height || rig.height;
    dpr = Math.min(3, Math.max(1, window.devicePixelRatio || 1));
    const pixelsWide = Math.max(1, Math.round(width * dpr));
    const pixelsHigh = Math.max(1, Math.round(height * dpr));
    if (canvas.width !== pixelsWide || canvas.height !== pixelsHigh || base.width !== pixelsWide || base.height !== pixelsHigh) {
      canvas.width = base.width = overlay.width = pixelsWide;
      canvas.height = base.height = overlay.height = pixelsHigh;
      lastStamp = '';
      baseDirty = true;
    }
  }

  function cacheBody() {
    if (!baseDirty || status !== 'ready') return;
    const paintBody = ctx => {
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(body, 0, 0, body.naturalWidth, body.naturalHeight,
        rig.body.x, rig.body.y, rig.body.width, rig.body.height);
    };
    baseContext.setTransform(1, 0, 0, 1, 0, 0);
    baseContext.clearRect(0, 0, base.width, base.height);
    baseContext.setTransform(base.width / rig.width, 0, 0, base.height / rig.height, 0, 0);
    paintBody(baseContext);
    overlayContext.setTransform(1, 0, 0, 1, 0, 0);
    overlayContext.clearRect(0, 0, overlay.width, overlay.height);
    overlayContext.setTransform(overlay.width / rig.width, 0, 0, overlay.height / rig.height, 0, 0);
    for (const region of rig.overlays) {
      overlayContext.save();
      overlayContext.beginPath();
      const points = region.points ?? region.polygon;
      if (points?.length) {
        overlayContext.moveTo(points[0][0], points[0][1]);
        for (const point of points.slice(1)) overlayContext.lineTo(point[0], point[1]);
        overlayContext.closePath();
      } else {
        const rect = region.rect ?? [region.x, region.y, region.width, region.height];
        overlayContext.rect(...rect);
      }
      overlayContext.clip();
      paintBody(overlayContext);
      overlayContext.restore();
    }
    // Original cuff pixels sit over the moving wrist. The body layer has the
    // cuff removed, so its antialiased edges are painted exactly once.
    overlayContext.imageSmoothingEnabled = true;
    overlayContext.imageSmoothingQuality = 'high';
    overlayContext.drawImage(cuff, 0, 0, cuff.naturalWidth, cuff.naturalHeight,
      rig.body.x, rig.body.y, rig.body.width, rig.body.height);
    baseDirty = false;
  }

  function paintHand(frame) {
    const image = hands[frame.image];
    if (!image) return;
    context.setTransform(canvas.width / rig.width, 0, 0, canvas.height / rig.height, 0, 0);
    if (handRotation) {
      context.translate(rig.pivot[0], rig.pivot[1]);
      context.rotate(handRotation);
      context.translate(-rig.pivot[0], -rig.pivot[1]);
    }
    context.drawImage(image, frame.x, frame.y, frame.width, frame.height,
      frame.drawX, frame.drawY, frame.drawWidth, frame.drawHeight);
  }

  function draw(force = false) {
    if (status !== 'ready' || destroyed) return;
    if (dpr !== Math.min(3, Math.max(1, window.devicePixelRatio || 1))) fit();
    cacheBody();
    const frame = rig.frames[currentFrame];
    if (canvas.dataset.characterFrame !== frame.name) canvas.dataset.characterFrame = frame.name;
    if (canvas.dataset.characterSequence !== sequenceName) canvas.dataset.characterSequence = sequenceName;
    if (canvas.dataset.characterPhase !== phase) canvas.dataset.characterPhase = phase;
    const stamp = `${currentFrame}:${handRotation.toFixed(5)}:${canvas.width}:${canvas.height}`;
    if (!force && stamp === lastStamp) return;
    lastStamp = stamp;
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = 'high';
    if (frame.layer === 'back') paintHand(frame);
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.drawImage(base, 0, 0);
    if (frame.layer === 'front') paintHand(frame);
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.drawImage(overlay, 0, 0);
    drawCount++;
  }

  function setKey(seconds) {
    const stop = stopAt(sequence, seconds);
    currentFrame = reduced ? rig.rest : stop.frame;
    phase = reduced || sequenceName === 'idle' ? 'rest' : stop.phase;
    const progress = Math.max(0, Math.min(1, (seconds - stop.start) / (stop.end - stop.start)));
    // One eased wrist cycle; the sleeve, shoulder and body remain untouched.
    const eased = progress * progress * (3 - 2 * progress);
    handRotation = reduced ? 0 : Math.sin(eased * Math.PI * 2) * stop.waveDegrees * Math.PI / 180;
  }

  function tick(_time, deltaMilliseconds) {
    if (destroyed || status !== 'ready' || paused()) return;
    const dt = Math.min(.064, Math.max(0, deltaMilliseconds / 1000));
    clock += dt;
    sequenceTime += dt;
    if (sequenceTime >= sequence.duration) {
      if (looping) sequenceTime %= sequence.duration;
      else {
        const callback = complete;
        complete = null;
        select('idle');
        callback?.();
        if (destroyed) return;
      }
    }
    setKey(sequenceTime);
    draw();
  }

  function subscribe() {
    const stillRest = sequenceName === 'idle' && sequence.stops.length === 1;
    const shouldRun = !destroyed && status === 'ready' && !paused() && !stillRest;
    if (shouldRun === subscribed) return;
    subscribed = shouldRun;
    if (subscribed) gsap.ticker.add(tick); else gsap.ticker.remove(tick);
  }

  function select(name, settings = {}) {
    if (destroyed) return 0;
    const selected = rig.sequences[name];
    if (!selected) throw new TypeError(`Unknown character animation: ${name}`);
    sequenceName = name;
    sequence = selected;
    sequenceTime = 0;
    looping = settings.loop ?? (name === 'idle' || selected.loop);
    complete = typeof settings.onComplete === 'function' ? settings.onComplete : null;
    setKey(0);
    draw(true);
    subscribe();
    return selected.duration;
  }

  function onVisibility() { hidden = document.hidden; subscribe(); }
  function onResize() { if (!destroyed) { fit(); draw(true); } }
  document.addEventListener('visibilitychange', onVisibility);
  window.addEventListener('resize', onResize);
  const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(onResize) : null;
  observer?.observe(canvas);
  const releaseObservers = () => {
    observer?.disconnect();
    window.removeEventListener('resize', onResize);
    document.removeEventListener('visibilitychange', onVisibility);
  };
  fit();
  const ready = Promise.all([body, cuff, ...hands].map(image => image.decode())).then(() => {
    if (destroyed) return;
    for (const frame of rig.frames) {
      const image = hands[frame.image];
      if (!image || frame.x < 0 || frame.y < 0 || frame.x + frame.width > image.naturalWidth || frame.y + frame.height > image.naturalHeight) {
        throw new RangeError(`The atlas rectangle for ${frame.name} lies outside its image.`);
      }
    }
    status = 'ready';
    baseDirty = true;
    fit();
    setKey(sequenceTime);
    draw(true);
    subscribe();
  }).catch(error => {
    if (destroyed) return;
    status = 'error';
    subscribe();
    releaseObservers();
    throw error;
  });

  return {
    ready,
    play: select,
    pause() { manualPause = true; subscribe(); },
    resume() { manualPause = false; subscribe(); },
    setReducedMotion(value) {
      reduced = Boolean(value);
      if (reduced) {
        complete = null;
        sequenceName = 'idle';
        sequence = rig.sequences.idle;
        sequenceTime = clock = 0;
        currentFrame = rig.rest;
        phase = 'rest';
        handRotation = 0;
        draw(true);
      }
      subscribe();
    },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      status = 'destroyed';
      complete = null;
      subscribe();
      releaseObservers();
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.clearRect(0, 0, canvas.width, canvas.height);
      base.width = overlay.width = 1;
      base.height = overlay.height = 1;
    },
    get state() {
      return { status, sequence: sequenceName, phase, frame: rig.frames[currentFrame].name,
        elapsed: sequenceTime, duration: sequence.duration, clock, paused: paused(),
        reducedMotion: reduced, frameCount: rig.frames.length, drawCount,
        rotationDegrees: handRotation * 180 / Math.PI };
    },
  };
}
