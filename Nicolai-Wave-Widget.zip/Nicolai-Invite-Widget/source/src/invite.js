import { gsap } from 'gsap';
import styles from './styles.css';
import { createCharacter, CHARACTER_SIZE } from './character-animation.js';

const DEFAULT_MESSAGE = 'Want to play a game?';
const mounts = new WeakMap();

function gameURL(value) {
  const href = String(value ?? '#game').trim();
  const url = new URL(href, document.baseURI);
  if (!['http:', 'https:', 'file:'].includes(url.protocol)) {
    throw new TypeError('Use an http(s) URL, a relative game path, or a page anchor.');
  }
  return href || '#game';
}

/** Mount one self-contained Nicolai invitation. Assets and GSAP are bundled. */
export function mount(options = {}) {
  const parent = options.parent ?? document.body;
  if (!(parent instanceof HTMLElement)) throw new TypeError('parent must be an HTML element.');
  const href = gameURL(options.href);
  // Re-mounting in a SPA cleans up its old instance and its animations.
  mounts.get(parent)?.destroy();
  const host = document.createElement('div');
  host.dataset.nicolaiInvite = '';
  host.dataset.status = 'loading';
  if (options.bottom != null) host.style.setProperty('--nicolai-bottom', String(options.bottom));
  const shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = styles;
  shadow.append(style);

  const viewport = document.createElement('div');
  viewport.className = 'viewport';
  viewport.inert = true;
  const link = document.createElement('a');
  link.className = 'invite-link';
  link.href = href;
  link.target = options.target === '_blank' ? '_blank' : '_self';
  if (link.target === '_blank') link.rel = 'noopener noreferrer';
  const message = String(options.message ?? DEFAULT_MESSAGE).slice(0, 100);
  link.setAttribute('aria-label', `Nicolai: ${message}`);
  link.tabIndex = -1;
  const bubble = document.createElement('span');
  bubble.className = 'bubble';
  const copy = document.createElement('span');
  copy.className = 'bubble-copy';
  copy.textContent = message;
  const arrow = document.createElement('span');
  arrow.className = 'bubble-arrow';
  const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  icon.setAttribute('width', '12');
  icon.setAttribute('height', '12');
  icon.setAttribute('viewBox', '0 0 12 12');
  const iconPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  iconPath.setAttribute('d', 'M2 10 10 2M3 2h7v7');
  iconPath.setAttribute('fill', 'none');
  iconPath.setAttribute('stroke', 'currentColor');
  iconPath.setAttribute('stroke-width', '1.5');
  iconPath.setAttribute('stroke-linecap', 'round');
  iconPath.setAttribute('stroke-linejoin', 'round');
  icon.append(iconPath);
  arrow.append(icon);
  arrow.setAttribute('aria-hidden', 'true');
  copy.append(arrow);
  bubble.append(copy);
  const figure = document.createElement('span');
  figure.className = 'figure';
  figure.setAttribute('aria-hidden', 'true');
  figure.style.aspectRatio = `${CHARACTER_SIZE[0]} / ${CHARACTER_SIZE[1]}`;
  const canvas = document.createElement('canvas');
  canvas.className = 'character-canvas';
  canvas.setAttribute('aria-hidden', 'true');
  figure.append(canvas);
  link.append(bubble, figure);
  const dismiss = document.createElement('button');
  dismiss.className = 'dismiss';
  dismiss.type = 'button';
  dismiss.setAttribute('aria-label', 'Dismiss game invitation');
  dismiss.tabIndex = -1;
  const cross = document.createElement('span');
  cross.textContent = '×';
  cross.setAttribute('aria-hidden', 'true');
  dismiss.append(cross);
  viewport.append(link, dismiss);
  shadow.append(viewport);
  parent.append(host);

  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  let reduced = preference.matches;
  const character = createCharacter(canvas, { reducedMotion: reduced });
  character.pause();
  let status = 'loading';
  let main = null;
  let outro = null;
  let lastGreeting = -Infinity;
  let replayAfterLoad = false;
  const listeners = [];
  const listen = (node, type, callback) => {
    node.addEventListener(type, callback);
    listeners.push(() => node.removeEventListener(type, callback));
  };
  const setStatus = value => { status = value; host.dataset.status = value; };
  const cancel = () => {
    main?.kill(); outro?.kill();
    main = outro = null;
    gsap.killTweensOf([figure, bubble, dismiss, arrow]);
  };
  const neutral = () => {
    gsap.set(figure, { x: 0, y: 0, rotation: -41, opacity: 1 });
    gsap.set([bubble, dismiss], { opacity: 1, x: 0, y: 0, scale: 1 });
    gsap.set(arrow, { x: 0, y: 0 });
  };
  const greet = (name = 'greeting') => {
    lastGreeting = performance.now();
    character.play(name);
    if (!document.hidden) character.resume();
  };
  function reveal(instant = false) {
    if (status === 'destroyed' || status === 'dismissed') return;
    cancel();
    setStatus('visible');
    link.tabIndex = 0;
    dismiss.tabIndex = 0;
    viewport.inert = false;
    neutral();
    character.setReducedMotion(reduced);
    if (reduced || instant) {
      character.play('idle');
      if (!document.hidden) character.resume();
      return;
    }
    const delay = Math.max(0, Math.min(30, Number(options.delay ?? .65) || 0));
    gsap.set(figure, { x: 160, rotation: -41, opacity: 0 });
    gsap.set(bubble, { scale: .98, y: 3, opacity: 0 });
    gsap.set(dismiss, { opacity: 0 });
    // No hidden controls take keyboard focus while waiting to enter.
    link.tabIndex = dismiss.tabIndex = -1;
    viewport.inert = true;
    character.pause();
    main = gsap.timeline({ delay, paused: document.hidden });
    main.to(figure, { x: 0, opacity: 1, duration: .72, ease: 'power2.out' })
      .to(bubble, { scale: 1, y: 0, opacity: 1, duration: .3, ease: 'power1.out' }, .48)
      .to(dismiss, { opacity: 1, duration: .25 }, .62)
      .call(() => {
        link.tabIndex = dismiss.tabIndex = 0;
        viewport.inert = false;
        if (!document.hidden) character.resume();
      }, [], .78);
    main.call(() => greet('greeting'), [], .58);
  }
  function replay() {
    if (status === 'destroyed' || status === 'dismissed' || reduced) return;
    if (status === 'loading') { replayAfterLoad = true; return; }
    if (performance.now() - lastGreeting < 250) return;
    cancel();
    neutral();
    link.tabIndex = dismiss.tabIndex = 0;
    viewport.inert = false;
    greet('greeting');
  }
  function dismissInvite() {
    if (status === 'destroyed' || status === 'dismissed') return;
    cancel();
    character.pause();
    setStatus('dismissed');
    link.tabIndex = dismiss.tabIndex = -1;
    host.style.pointerEvents = 'none';
    host.inert = true;
    if (reduced || document.hidden) { host.hidden = true; return; }
    outro = gsap.timeline({ onComplete: () => { host.hidden = true; } })
      .to([bubble, dismiss], { opacity: 0, duration: .18 })
      .to(figure, { x: 180, duration: .38, ease: 'power2.in' }, .06);
  }
  listen(dismiss, 'click', dismissInvite);
  // Moving art can pass underneath a stationary cursor. Finish the current
  // gesture before responding, so hover never snaps an arm back to its first key.
  const respond = () => {
    if (character.state.sequence === 'idle' && performance.now() - lastGreeting > 12000) replay();
  };
  listen(link, 'pointerenter', respond);
  listen(link, 'focus', respond);
  listen(shadow, 'keydown', event => {
    if (event.key === 'Escape') { event.preventDefault(); dismissInvite(); }
  });
  listen(document, 'visibilitychange', () => {
    if (document.hidden) character.pause();
    else if (status === 'visible' && !viewport.inert) character.resume();
    [main, outro].forEach(timeline => {
      if (!timeline) return;
      if (document.hidden) timeline.pause(); else timeline.resume();
    });
  });
  listen(preference, 'change', () => {
    reduced = preference.matches;
    if (status === 'visible') reveal(true);
    else if (status === 'dismissed') { cancel(); host.hidden = true; }
  });
  const ready = character.ready.catch(() => {
    // Keep the ordinary HTML link usable if the illustrated atlas cannot decode.
    canvas.hidden = true;
  }).then(() => {
    if (status !== 'loading') return;
    reveal();
    if (replayAfterLoad) replay();
  });
  const instance = {
    element: host,
    ready,
    replay,
    dismiss: dismissInvite,
    destroy() {
      if (status === 'destroyed') return;
      cancel();
      character.destroy();
      listeners.forEach(remove => remove());
      setStatus('destroyed');
      host.remove();
      if (mounts.get(parent) === instance) mounts.delete(parent);
    },
    get state() { return { status, reducedMotion: reduced, paused: document.hidden, character: character.state }; },
  };
  mounts.set(parent, instance);
  return instance;
}
