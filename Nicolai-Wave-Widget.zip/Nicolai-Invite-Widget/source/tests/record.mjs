import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = process.env.PREVIEW_DIR || path.join(root, 'test-output');
const duration = Number(process.env.DURATION_SECONDS || 6);
const outputName = process.env.VIDEO_NAME || 'Nicolai-Invite-Wave.mp4';
await fs.mkdir(output, { recursive: true });
const html = await fs.readFile(process.env.STANDALONE_HTML || path.join(root, 'release/Nicolai-Invite.html'));
const server = http.createServer((request, response) => {
  response.writeHead(200, { 'Content-Type': 'text/html' });
  response.end(html);
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, recordVideo: { dir: path.join(output, 'recordings'), size: { width: 1280, height: 800 } } });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const video = page.video();
try {
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  await page.waitForTimeout((duration + Math.max(0, Number(process.env.LEAD_IN_TRIM_SECONDS || 0)) + 1) * 1000);
  if (errors.length) throw new Error(errors.join('\n'));
  await context.close();
  const filename = path.join(output, outputName);
  const recording = await video.path();
  const probe = spawnSync('ffprobe', ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=color_range', '-of', 'json', recording], { encoding: 'utf8' });
  const range = probe.status === 0 && JSON.parse(probe.stdout).streams?.[0]?.color_range === 'pc' ? 'pc' : 'auto';
  // Playwright can prepend white browser startup frames before navigation.
  // Remove only that initial blank interval; an optional offset can shorten
  // the page's loading lead-in without cutting any of the actual greeting.
  const blankProbe = spawnSync('ffmpeg', ['-hide_banner', '-i', recording, '-vf', 'negate,blackdetect=d=0.1:pix_th=0.02:pic_th=0.995', '-an', '-f', 'null', '-'], { encoding: 'utf8' });
  const initialBlank = blankProbe.stderr.match(/black_start:0(?:\.0+)? black_end:([\d.]+)/);
  const trimStart = Math.max(0, Number(initialBlank?.[1] || 0) + Number(process.env.LEAD_IN_TRIM_SECONDS || 0));
  await new Promise((resolve, reject) => {
    // System FFmpeg can retain full-range JPEG values in Playwright's VP8
    // recording. Explicit conversion prevents washed-out cream/skin colors.
    const process = spawn('ffmpeg', ['-y', '-ss', String(trimStart), '-i', recording, '-t', String(duration), '-vf', `scale=in_range=${range}:out_range=tv`, '-an', '-c:v', 'libx264', '-crf', '20', '-pix_fmt', 'yuv420p', '-color_range', 'tv', '-r', '30', '-movflags', '+faststart', filename], { stdio: 'ignore' });
    process.on('error', reject);
    process.on('exit', code => code === 0 ? resolve() : reject(new Error(`ffmpeg exited ${code}`)));
  });
  const filmstrip = path.join(output, outputName.replace(/\.mp4$/i, '-filmstrip.png'));
  const detail = path.join(output, outputName.replace(/\.mp4$/i, '-detail.mp4'));
  await new Promise((resolve, reject) => {
    const process = spawn('ffmpeg', ['-y', '-i', filename, '-vf', 'crop=420:380:860:420,scale=840:760:flags=lanczos', '-an', '-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', detail], { stdio: 'ignore' });
    process.on('error', reject);
    process.on('exit', code => code === 0 ? resolve() : reject(new Error(`detail ffmpeg exited ${code}`)));
  });
  await new Promise((resolve, reject) => {
    const process = spawn('ffmpeg', ['-y', '-i', filename, '-vf', `fps=2,crop=380:340:900:440,tile=4x${Math.ceil(duration / 2)}`, '-frames:v', '1', filmstrip], { stdio: 'ignore' });
    process.on('error', reject);
    process.on('exit', code => code === 0 ? resolve() : reject(new Error(`filmstrip ffmpeg exited ${code}`)));
  });
  console.log(filename);
  console.log(detail);
  console.log(filmstrip);
} finally {
  await browser.close();
  await new Promise(resolve => server.close(resolve));
}
