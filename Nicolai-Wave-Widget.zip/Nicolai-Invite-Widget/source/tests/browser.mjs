import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Exercise the distributable, not a test-only rendering implementation.
// PLAYWRIGHT_MODULE=/path/to/playwright/index.mjs node tests/browser.mjs
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = process.env.PREVIEW_DIR || path.join(root, 'test-output');
const standalone = process.env.STANDALONE_HTML || path.join(root, 'release/Nicolai-Invite.html');
await fs.mkdir(output, { recursive: true });
const bundle = await fs.readFile(path.join(root, 'release/nicolai-invite.min.js'));
const errors = [];
const checks = [];
const server = http.createServer(async (req, res) => {
  if (req.url === '/standalone.html') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end(await fs.readFile(standalone));
  }
  if (req.url === '/invite.js') {
    res.writeHead(200, { 'Content-Type': 'text/javascript' });
    return res.end(bundle);
  }
  if (req.url === '/game-target') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end('<!doctype html><title>Game destination</title><h1>Game reached</h1>');
  }
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Widget QA</title><style>
  *{box-sizing:border-box}html,body{margin:0;min-height:100%;background:#f6f4ef;color:#13293a;font:16px system-ui}main{padding:48px;min-height:140vh}h1{max-width:500px;font-size:48px;line-height:1.08}#underneath{position:fixed;left:20px;top:50%;padding:16px;background:#123e39;color:white;border:0;border-radius:8px;cursor:pointer}#log{display:block;margin-top:16px}
  </style><main><p>IN GOOD COMPANY</p><h1>A little perspective.<br>A little play.</h1><p>The widget should leave this page usable.</p><button id="underneath" onclick="this.dataset.clicks=String(+(this.dataset.clicks||0)+1)">Page action</button></main><script src="/invite.js"></script></html>`);
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });

function record(name) { checks.push(name); console.log(`PASS ${name}`); }
async function fixture(options = {}, contextOptions = {}) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, ...contextOptions });
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(origin);
  await page.evaluate(async options => {
    window.invite = window.NicolaiInvite.mount({ href: '/game-target', delay: 0, ...options });
    await window.invite.ready;
  }, options);
  await page.waitForFunction(() => window.invite.state.status === 'visible');
  await page.waitForTimeout(1600);
  return { context, page, host: page.locator('[data-nicolai-invite]'), link: page.locator('[data-nicolai-invite] a.invite-link'), dismiss: page.locator('[data-nicolai-invite] button.dismiss') };
}
async function noOverflow(page, name) {
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `${name}: horizontal overflow`);
}

try {
  {
    const { context, page, host, link, dismiss } = await fixture();
    await link.waitFor({ state: 'visible' });
    assert.match(await link.textContent(), /Want to play a game\?/);
    assert.equal(await link.getAttribute('href'), '/game-target');
    assert.equal(await dismiss.getAttribute('aria-label'), 'Dismiss game invitation');
    assert.equal(await host.locator('canvas').evaluate(canvas => {
      const context = canvas.getContext('2d');
      if (!context || !canvas.width || !canvas.height) return false;
      const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
      return pixels.some((value, index) => index % 4 === 3 && value > 0);
    }), true, 'illustrated character layers decoded and rendered visible pixels');
    assert.equal(await page.evaluate(() => getComputedStyle(document.querySelector('[data-nicolai-invite]')).position), 'fixed');
    await noOverflow(page, 'desktop');
    await page.locator('#underneath').click();
    assert.equal(await page.locator('#underneath').getAttribute('data-clicks'), '1');
    record('Desktop widget, exact message, real link and page click-through');
    await page.screenshot({ path: path.join(output, 'Nicolai-Invite-desktop.png') });
    await link.focus();
    await page.keyboard.press('Enter');
    await page.waitForURL(`${origin}/game-target`);
    assert.equal(await page.locator('h1').textContent(), 'Game reached');
    record('Keyboard activation follows configured game URL');
    await context.close();
  }
  {
    const { context, page, host } = await fixture({}, { deviceScaleFactor: 2 });
    // Sample the whole explicit greeting after entrance motion has settled.
    // Only the original hand may move. The full-size sleeve, torso and head
    // must remain the same painted pixels throughout the single wrist wave.
    await page.waitForFunction(() => window.invite.state.character.sequence === 'idle');
    await page.evaluate(() => window.invite.replay());
    const samples = await host.locator('canvas').evaluate(async canvas => {
      const context = canvas.getContext('2d');
      const samples = [];
      const greetingDuration = window.invite.state.character.duration;
      const logical = { width: 448, height: 544 };
      // Painted details and silhouette edges, not blank stability samples.
      // The sleeve sample stays below the wrist and guards against shoulder
      // shifts and frame-by-frame suit changes.
      const stableRegions = {
        head: [210, 15, 125, 58],
        torso: [280, 310, 25, 50],
        sleeve: [55, 235, 70, 65],
        rightOutline: [398, 240, 49, 160],
      };
      const hashPixels = pixels => {
        let hash = 2166136261;
        for (let i = 0; i < pixels.length; i++) hash = Math.imul(hash ^ pixels[i], 16777619);
        return hash >>> 0;
      };
      const readRegion = ([x, y, width, height]) => {
        const sx = canvas.width / logical.width, sy = canvas.height / logical.height;
        const pixels = context.getImageData(Math.round(x * sx), Math.round(y * sy), Math.round(width * sx), Math.round(height * sy)).data;
        let opaque = 0;
        for (let i = 3; i < pixels.length; i += 4) if (pixels[i] > 0) opaque++;
        return { hash: hashPixels(pixels), opaque, pixels: pixels.length / 4 };
      };
      for (let sample = 0; sample < 42; sample++) {
        const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
        const bounds = canvas.getBoundingClientRect();
        samples.push({
          frame: canvas.dataset.characterFrame,
          sequence: canvas.dataset.characterSequence,
          phase: window.invite.state.character.phase,
          rotationDegrees: window.invite.state.character.rotationDegrees,
          hash: hashPixels(pixels),
          stable: Object.fromEntries(Object.entries(stableRegions).map(([name, region]) => [name, readRegion(region)])),
          bounds: { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height },
        });
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      return { samples, greetingDuration, width: canvas.width, height: canvas.height, cssWidth: canvas.clientWidth, cssHeight: canvas.clientHeight };
    });
    assert(new Set(samples.samples.map(sample => sample.hash)).size >= 6, 'actual hand pixels animate continuously through the wave');
    assert(samples.width >= samples.cssWidth * 2 - 1 && samples.height >= samples.cssHeight * 2 - 1, 'canvas resolution supports a 2× display');
    assert.equal(await page.evaluate(() => window.invite.state.character.sequence), 'idle', 'single wave has settled within 4.2 seconds');
    assert(samples.samples.filter(sample => sample.phase === 'wave').length >= 5, 'relaxed wave remains visible for at least half a second');
    assert(samples.samples.every(sample => sample.phase !== 'beckon'), 'the invitation contains only a wave, with no beckoning gesture');
    assert(samples.greetingDuration <= 2.4, 'the complete greeting stays short');
    const rotations = samples.samples.map(sample => sample.rotationDegrees);
    assert(rotations.every(Number.isFinite), 'wrist rotation remains finite');
    assert(Math.max(...rotations) > 3 && Math.min(...rotations) < -3, 'hand completes both directions of one clear wave');
    assert(rotations.every(angle => Math.abs(angle) <= 7), 'wrist sweep stays restrained');
    const directions = rotations.filter(angle => Math.abs(angle) > .5).map(Math.sign).filter((sign, index, signs) => !index || sign !== signs[index - 1]);
    assert.equal(directions.length, 2, 'hand makes one wave cycle, without repeated waving');
    for (const region of ['head', 'torso', 'sleeve', 'rightOutline']) {
      assert(samples.samples.every(sample => sample.stable[region].opaque > 100), `${region} stability region contains real painted pixels`);
      assert.equal(new Set(samples.samples.map(sample => sample.stable[region].hash)).size, 1, `${region} pixels stay identical while the hand moves`);
    }
    assert(samples.samples[0].stable.rightOutline.opaque < samples.samples[0].stable.rightOutline.pixels, 'outline check includes the painted silhouette against transparency');
    for (const key of ['x', 'y', 'width', 'height']) {
      const values = samples.samples.map(sample => sample.bounds[key]);
      assert(Math.max(...values) - Math.min(...values) < .01, `canvas ${key} stays fixed after entrance`);
    }
    await fs.writeFile(path.join(output, 'Nicolai-Wave-motion-samples.json'), JSON.stringify(samples, null, 2));
    record('One wrist wave animates while original sleeve/head/torso pixels and canvas position stay fixed');
    await context.close();
  }
  {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    await page.clock.install();
    await page.goto(origin);
    await page.evaluate(async () => {
      window.invite = NicolaiInvite.mount({ href: '/game-target', delay: 0 });
      await window.invite.ready;
    });
    await page.clock.runFor(5000);
    assert.equal(await page.evaluate(() => invite.state.character.sequence), 'idle', 'first greeting settles');
    await page.evaluate(() => {
      window.unpromptedGestures = [];
      const canvas = invite.element.shadowRoot.querySelector('canvas');
      window.sequenceObserver = new MutationObserver(() => {
        if (canvas.dataset.characterSequence !== 'idle') unpromptedGestures.push(canvas.dataset.characterSequence);
      });
      sequenceObserver.observe(canvas, { attributes: true, attributeFilter: ['data-character-sequence'] });
    });
    await page.clock.runFor(41000);
    assert.deepEqual(await page.evaluate(() => window.unpromptedGestures), [], 'no automatic waves at the former 20/40-second repeat points');
    await page.evaluate(() => window.sequenceObserver.disconnect());
    record('Invitation stays quietly at rest instead of automatically waving again');
    await context.close();
  }
  for (const viewport of [{ width: 390, height: 844 }, { width: 320, height: 568 }, { width: 844, height: 390 }]) {
    const { context, page, link, dismiss } = await fixture({}, { viewport, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    await noOverflow(page, `touch ${viewport.width}`);
    const bounds = await dismiss.boundingBox();
    assert(bounds && bounds.x >= 0 && bounds.y >= 0 && bounds.x + bounds.width <= viewport.width + 1 && bounds.y + bounds.height <= viewport.height + 1, 'dismiss within viewport');
    const linkBox = await link.boundingBox();
    assert(linkBox && linkBox.width > 40 && linkBox.height > 40, 'usable link');
    if (viewport.width === 390) await page.screenshot({ path: path.join(output, 'Nicolai-Invite-mobile.png') });
    await dismiss.tap();
    await page.waitForFunction(() => window.invite.state.status === 'dismissed');
    record(`Touch layout ${viewport.width}×${viewport.height}, no overflow, dismiss reachable`);
    await context.close();
  }
  {
    const { context, page, dismiss, host } = await fixture();
    await dismiss.focus();
    await page.keyboard.press('Enter');
    await page.waitForFunction(() => window.invite.state.status === 'dismissed');
    await page.waitForTimeout(650);
    assert.equal(await page.evaluate(() => window.invite.state.status), 'dismissed');
    await page.evaluate(() => window.invite.destroy());
    assert.equal(await host.count(), 0);
    assert.equal(await page.evaluate(() => window.invite.state.status), 'destroyed');
    await page.evaluate(() => { window.invite.destroy(); window.invite.replay(); window.invite.dismiss(); });
    assert.equal(await host.count(), 0);
    record('Keyboard dismiss, destroy and repeated cleanup leave no widget');
    await context.close();
  }
  {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(origin);
    await page.evaluate(async () => {
      window.firstInvite = window.NicolaiInvite.mount({ href: '/game-target', delay: 15 });
      await window.firstInvite.ready;
    });
    assert.equal(await page.evaluate(() => firstInvite.element.shadowRoot.querySelector('.viewport').inert), true, 'waiting controls are inert');
    await page.keyboard.press('Tab');
    await page.keyboard.press('Tab');
    assert.equal(await page.evaluate(() => document.activeElement?.hasAttribute('data-nicolai-invite')), false, 'hidden invitation cannot receive tab focus');
    const hiddenPoint = await page.evaluate(() => {
      const host = firstInvite.element.getBoundingClientRect();
      const button = document.querySelector('#underneath');
      Object.assign(button.style, { left: `${host.left + 30}px`, top: `${host.top + 35}px`, width: '120px', height: '50px', padding: '0' });
      return { x: host.left + 80, y: host.top + 55 };
    });
    await page.mouse.click(hiddenPoint.x, hiddenPoint.y);
    assert.equal(await page.locator('#underneath').getAttribute('data-clicks'), '1', 'transparent waiting bubble does not intercept the page');
    await page.evaluate(async () => {
      window.invite = window.NicolaiInvite.mount({ href: '/game-target', delay: 0 });
      await window.invite.ready;
    });
    await page.waitForTimeout(1700);
    assert.equal(await page.evaluate(() => firstInvite.state.status), 'destroyed');
    assert.equal(await page.locator('[data-nicolai-invite]').count(), 1);
    assert.equal(await page.evaluate(() => invite.element.shadowRoot.querySelector('.viewport').inert), false);
    const emptyPoint = await page.evaluate(() => {
      const host = invite.element.getBoundingClientRect();
      const button = document.querySelector('#underneath');
      Object.assign(button.style, { left: `${host.left + 2}px`, top: `${host.top + 177}px`, width: '20px', height: '20px', padding: '0' });
      return { x: host.left + 7, y: host.top + 182 };
    });
    await page.mouse.click(emptyPoint.x, emptyPoint.y);
    assert.equal(await page.locator('#underneath').getAttribute('data-clicks'), '2', 'empty visible host region does not intercept the page');
    record('Delayed controls stay inert, empty areas pass clicks through, repeat mount cleans up');
    await context.close();
  }
  {
    const { context, page } = await fixture({}, { reducedMotion: 'reduce' });
    assert.equal(await page.evaluate(() => window.invite.state.reducedMotion), true);
    const before = await page.screenshot();
    await page.waitForTimeout(900);
    const after = await page.screenshot();
    assert(before.equals(after), 'reduced-motion frame stays visually static');
    await page.screenshot({ path: path.join(output, 'Nicolai-Invite-reduced-motion.png') });
    record('Reduced motion displays a static, usable invitation');
    await context.close();
  }
  {
    const { context, page } = await fixture();
    await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange')); });
    assert.equal(await page.evaluate(() => window.invite.state.paused), true);
    const before = await page.screenshot();
    await page.waitForTimeout(500);
    assert(before.equals(await page.screenshot()), 'hidden-tab animation frame stays still');
    await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: false }); document.dispatchEvent(new Event('visibilitychange')); });
    assert.equal(await page.evaluate(() => window.invite.state.paused), false);
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.waitForFunction(() => window.invite.state.reducedMotion);
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await page.waitForFunction(() => !window.invite.state.reducedMotion);
    record('Visibility pause/resume and live motion preference changes');
    await context.close();
  }
  {
    const payload = '<img src=x onerror="window.injected=true"> & "hello"';
    const { context, page, link } = await fixture({ message: payload, href: 'https://example.com/game?edition=nyc&character=nicolai', target: '_blank' });
    assert((await link.textContent()).includes(payload), 'message is literal text');
    assert.equal(await page.evaluate(() => window.injected), undefined);
    assert.equal(await link.getAttribute('target'), '_blank');
    assert.match(await link.getAttribute('rel') || '', /noopener/);
    assert.equal(await link.getAttribute('href'), 'https://example.com/game?edition=nyc&character=nicolai');
    const unsafe = await page.evaluate(async () => {
      try {
        const instance = window.NicolaiInvite.mount({ href: 'javascript:window.injected=true', delay: 0 });
        await instance.ready;
        const href = instance.element.shadowRoot.querySelector('a').href;
        instance.destroy();
        return { rejected: false, href };
      } catch { return { rejected: true }; }
    });
    assert(unsafe.rejected || !unsafe.href.startsWith('javascript:'), 'unsafe executable URL blocked');
    record('Literal custom text, external link safety and executable URL rejection');
    await context.close();
  }
  try {
    await fs.access(standalone);
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    const requests = [];
    page.on('request', request => requests.push(request.url()));
    page.on('pageerror', error => errors.push(error.message));
    // The managed browser disallows file://. Serve the exact standalone bytes;
    // only this document request is permitted, with no external asset fetches.
    await page.goto(`${origin}/standalone.html`);
    await page.locator('[data-nicolai-invite] a.invite-link').waitFor({ state: 'visible' });
    await page.waitForTimeout(2300);
    assert.deepEqual(requests.filter(url => /^https?:/.test(url)), [`${origin}/standalone.html`], 'standalone needs no asset requests');
    await noOverflow(page, 'standalone');
    await page.screenshot({ path: path.join(output, 'Nicolai-Invite-preview.png') });
    record('Self-contained downloadable demo runs without network assets');
    await context.close();
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    console.log('SKIP standalone: build the downloadable HTML to exercise it');
  }
  assert.deepEqual(errors, [], 'no browser exceptions');
  record('No browser exceptions');
  console.log(JSON.stringify({ passed: checks.length, checks }, null, 2));
} finally {
  await browser.close();
  await new Promise(resolve => server.close(resolve));
}
