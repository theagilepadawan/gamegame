import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = process.env.PREVIEW_DIR || path.join(root, 'test-output');
const framesDirectory = path.join(output, 'nicolai-cartoon-frames');
await fs.mkdir(framesDirectory, { recursive: true });
const html = await fs.readFile(process.env.STANDALONE_HTML || path.join(root, 'release/Nicolai-Invite.html'));
const server = http.createServer((_request, response) => {
  response.writeHead(200, { 'Content-Type': 'text/html' });
  response.end(html);
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
try {
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  const frames = await page.evaluate(async () => {
    await window.invite.ready;
    const canvas = window.invite.element.shadowRoot.querySelector('canvas');
    const frames = new Map();
    const start = performance.now();
    while (performance.now() - start < 12500) {
      const name = canvas.dataset.characterFrame;
      if (name && !frames.has(name)) frames.set(name, { name, time: (performance.now() - start) / 1000, image: canvas.toDataURL('image/png') });
      await new Promise(requestAnimationFrame);
    }
    return [...frames.values()];
  });
  const files = [];
  for (const [index, frame] of frames.entries()) {
    const basename = `${String(index).padStart(2, '0')}-${frame.name.replace(/[^a-zA-Z0-9_-]/g, '_')}.png`;
    const file = path.join(framesDirectory, basename);
    await fs.writeFile(file, Buffer.from(frame.image.split(',')[1], 'base64'));
    files.push(file);
  }
  await fs.writeFile(path.join(framesDirectory, 'frames.json'), JSON.stringify(frames.map(({ name, time }) => ({ name, time })), null, 2));
  const sheet = path.join(output, 'Nicolai-Cartoon-authored-frames.png');
  const args = ['montage', '-background', '#f4f3eb', '-font', 'DejaVu-Sans', '-pointsize', '11', '-label', '%f', ...files, '-geometry', '190x280+8+8', '-tile', '6x', sheet];
  const montage = spawnSync('magick', args, { encoding: 'utf8' });
  if (montage.status !== 0) throw new Error(montage.stderr || 'Frame montage failed');
  console.log(`${frames.length} authored frames captured: ${sheet}`);
} finally {
  await browser.close();
  await new Promise(resolve => server.close(resolve));
}
