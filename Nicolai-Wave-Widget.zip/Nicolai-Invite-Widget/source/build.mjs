import { build } from 'esbuild';
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.dirname(fileURLToPath(import.meta.url));
const release = path.join(root, 'release');
await mkdir(release, { recursive: true });
const shared = {
  absWorkingDir: root,
  entryPoints: ['src/invite.js'],
  bundle: true,
  minify: true,
  target: ['es2020'],
  loader: { '.css': 'text', '.png': 'dataurl', '.webp': 'dataurl' },
  legalComments: 'inline',
};
await build({ ...shared, format: 'iife', globalName: 'NicolaiInvite', outfile: path.join(release, 'nicolai-invite.min.js') });
await build({ ...shared, format: 'esm', outfile: path.join(release, 'nicolai-invite.mjs') });
const code = await readFile(path.join(release, 'nicolai-invite.min.js'), 'utf8');
const template = await readFile(path.join(root, 'demo.html'), 'utf8');
const standalone = template.replace('<!-- NICOLAI_SCRIPT -->', () => `<script>${code.replace(/<\/script/gi, '<\\/script')}</script>`);
await writeFile(path.join(release, 'Nicolai-Invite.html'), standalone);
await writeFile(path.join(release, 'demo.html'), template.replace('<!-- NICOLAI_SCRIPT -->', '<script src="./nicolai-invite.min.js"></script>'));
await copyFile(path.join(root, 'README.md'), path.join(release, 'README.md'));
await copyFile(path.join(root, 'THIRD-PARTY-NOTICES.md'), path.join(release, 'THIRD-PARTY-NOTICES.md'));
console.log(`Built widget (GSAP + embedded cartoon sprite animation): ${(Buffer.byteLength(code) / 1024).toFixed(0)} KiB.`);
console.log(path.join(release, 'Nicolai-Invite.html'));

