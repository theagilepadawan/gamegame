# Third-party notices

This widget bundles GSAP 3.13.0 (core and CSSPlugin), copyright 2008–2025 GreenSock.
GSAP is distributed under the Standard “no charge” License:
https://gsap.com/standard-license/

The original GSAP copyright and license header remains in both JavaScript bundles.
GSAP is not MIT-licensed. Only the core/CSS animation functionality is included.

esbuild 0.28.2 (MIT) is a build-time dependency and is not shipped in the browser.

The Nicolai illustrations were generated from the supplied game character art
for this project. Their provenance and assembly are recorded in art/README.md.
